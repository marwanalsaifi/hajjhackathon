package com.example.alhalim.blockchain;

import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class Hajjregister extends AppCompatActivity {
    public FirebaseAuth mAuth;
    public DatabaseReference mData;
    public EditText mName;
    public EditText mAge;
    public EditText mCivilID;
    public EditText mDOB;
    public EditText mhealth;
    public Button mReg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hajjregister);
        mName = (EditText) findViewById(R.id.name2);
        mAge = (EditText) findViewById(R.id.age2);
        mCivilID = (EditText) findViewById(R.id.civil2);
        mDOB = (EditText) findViewById(R.id.dob2);
        mhealth = (EditText) findViewById(R.id.health2);
        mReg = (Button) findViewById(R.id.regbtn);
        mAuth = FirebaseAuth.getInstance();


        mReg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = mName.getText().toString();
                String hage = mAge.getText().toString();
                String hcivil = mCivilID.getText().toString();
                String hdob = mDOB.getText().toString();
                String hhealthy = mhealth.getText().toString();
                register_user(email, hage, hcivil, hdob, hhealthy);

            }
        });
    }

    private void register_user(final String email, final String hage, final String hcivil, final String hdob, final String hhealthy) {


        mAuth.createUserWithEmailAndPassword(email, hcivil).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                try {
                    if (task.isSuccessful()) {
                        FirebaseUser hajjdet =FirebaseAuth.getInstance().getCurrentUser();
                        String uid =hajjdet.getUid();
                        mData= FirebaseDatabase.getInstance().getReference().child("hajjdetail").child(uid);
                        HashMap<String,String> userMap=new HashMap<>();
                        userMap.put("civilNO",email);
                        userMap.put("name",hage);
                        userMap.put("email",hcivil);
                        userMap.put("password",hdob);
                        userMap.put("phone",hhealthy);
                        mData.setValue(userMap);
                        Toast.makeText(Hajjregister.this, "registeration seccess", Toast.LENGTH_LONG).show();

                    }else{

                        Toast.makeText(Hajjregister.this,  "error", Toast.LENGTH_LONG).show();
                    }
                }catch (Exception e){
                    e.printStackTrace();
                }
                }

        });
    }
}
