package com.example.alhalim.blockchain;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    public Button mAir,mHealth,mHajj;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mAir=(Button)findViewById(R.id.air);
        mHajj=(Button)findViewById(R.id.hajj);
        mHealth=(Button)findViewById(R.id.health);

        mAir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent airR = new Intent(MainActivity.this, Hajjregister.class);
                startActivity(airR);
            }
        });
    }
}
